#include "Genricdb.hpp"
// pure virtual functions we implement them in the son classes 